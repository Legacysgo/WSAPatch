//
// Created by Administrator on 2022.11.30.
//

#include "Log.h"

volatile Log::LogHandler Log::mHandler = nullptr;
