#ifndef WSAPATCH_WSAPATCH_H
#define WSAPATCH_WSAPATCH_H

#include "macros.h"

EXPORT_C void NS_WsaPatch_UnusedSymbol();

#endif //WSAPATCH_WSAPATCH_H
